# Terraria

## Minimum RAM warning
You may want to assign a minimum of 768 mb of RAM to a server as it will use around 650 mb to generate the world on the first start.

## Required Server Ports
tModloader, like Terraria, only requires a single port to run. The default is 7777

| Port    | default |
|---------|---------|
| Game    | 7777    |

#### Plugins may require ports to be added to the server.
