# Cuberite
A lightweight, fast and extensible game server for Minecraft

## Server Ports
The minecraft server requires a single port for access (default 25565) but plugins may require extra ports to enabled for the server.


| Port     | default |
|----------|---------|
| Game     | 25565   |
| WebAdmin | 8080    |