# Purpur

Purpur is a fork of Paper and Tuinity which provides new configuration options.

See https://github.com/pl3xgaming/purpur for additional information.
