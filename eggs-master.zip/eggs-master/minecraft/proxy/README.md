# Minecraft Proxies

* [Java](/minecraft/proxy/java/)
  * [Waterfall](/minecraft/proxy/java/waterfall)
  * [Travertine](/minecraft/proxy/java/travertine)
  * [Velocity](/minecraft/proxy/java/velocity)
  * [TyphoonLimbo](/minecraft/proxy/java/typhoonlimbo)
* [Cross Platform](/minecraft/proxy/cross_platform)
    * [GeyserMC](/minecraft/proxy/cross_platform/geyser)
    * [Waterdog](/minecraft/proxy/cross_platform/waterdog)
	* DragonProxy abandoned in favour of GeyserMC.
