# Twitch Bots

### Some of these bots support other services but are primarily Twitch bots

#### PhantomBot [Homepage](https://phantombot.tv) [Egg](/bots/twitch/phantombot/)
#### sogeBot [Homepage](https://sogebot.xyz) [Egg](/bots/twitch/sogebots/)
