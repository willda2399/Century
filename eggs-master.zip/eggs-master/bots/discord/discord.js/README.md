# discord.js generic

This egg was designed to allow a user to pull their own nodejs discord bot from a repo.

There is an option to allow a user to upload their own files to run a bot.

The startup configs and commands may need changing to actually function properly.