# Bastion
### From their [Github](https://github.com/TheBastionBot/Bastion)
Give awesome perks to your Discord server!  

### Install notes
Due to rate limiting the console on the panel cannot keep up with the game console and the build will complete before the panel console may show it. Reloading the console will load it to the latest part of the log.  

## Running the bot
You need to enable both `Privileged Gateway Intents` for the bot to run.
Enable this from `https://discord.com/developers/applications/<applicationid>/bot`

### Server Ports
No Ports are required for the bastion bot.  