# discordgo generic
This egg was designed to allow a user to pull their own go discord bot from a repo.

The startup configs and commands may need changing to actually function properly.

Users cannot upload their own code as this is built to build the resulting bot.

`GO_PACKAGE` is the variable for the go repo i.e. `github.com/aurieh/ddg-ng`  
`EXECUTABLE` is the variable for the executable that is built i.e. `ddg-ng`