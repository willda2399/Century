# alt:v

### From the [alt:V](https://altv.mp) Site
alt:V Multiplayer a third-party multiplayer modification for Grand Theft Auto: V.

### Server Ports
Ports required to run the server in a table format.

| Port    | default |
|---------|---------|
| Game    | 7788    |
