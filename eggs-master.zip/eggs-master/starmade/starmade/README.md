# Starmade Server
### From their [Homepage](https://starmadedock.net/) - [Guide](https://www.star-made.org/help/setting_up_a_server)
The ultimate space sandbox. Participate in epic fleet battles, form alliances, strive to dominate entire galaxies and harness the universe’s resources for your industrious empire or the destruction of others. Customise your experience, the universe is yours!

### Server Ports
Ports required to run the server

| Port    | default |
|---------|---------|
| Game    | 4242    |
