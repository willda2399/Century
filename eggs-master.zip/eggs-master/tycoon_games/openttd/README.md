# OpenTTD (https://www.openttd.org)

OpenTTD is a business simulation game in which players try to earn money via transporting passengers and freight by road, rail, water and air. It is an open-source remake and expansion of the 1995 Chris Sawyer video game Transport Tycoon Deluxe

## Server Ports

| Port    | Default |
|---------|---------|
| Game    | 3797    |
| Admin   | 3977    |
