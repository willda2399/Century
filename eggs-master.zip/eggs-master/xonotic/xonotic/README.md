# Xonotic

The Free and Fast Arena Shooter

### Server Ports
Xonotic requires 1 port

| Port  | default |
|-------|---------|
| Game  | 26000   |