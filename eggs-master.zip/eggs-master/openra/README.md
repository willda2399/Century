# OpenRA Servers

OpenRA is a project that recreates and modernizes the classic Command & Conquer real time strategy games. 
We have developed a flexible open source game engine (the OpenRA engine) that provides 
a common platform for rebuilding and reimagining classic 2D and 2.5D RTS games (the OpenRA mods).