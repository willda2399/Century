### From their [Site](https://conanexiles.com/)
Conan Exiles is online multiplayer survival game set in the lands of Conan the Barbarian

### Minimum RAM warning
This server requires about 4096m to run properly.

### Server Ports
Ports required to run the server in a table format.

| Port    | default |
|---------|---------|
| Game    | 7777 |
| Steam Query | 27015 |

### More information can be found [here](https://forums.funcom.com/t/conan-exiles-dedicated-server-app-latest-version-1-0-21/21699)