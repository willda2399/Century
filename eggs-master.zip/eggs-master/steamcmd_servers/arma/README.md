# ARMA

ARMA is a series of first-person tactical military shooters, originally released for Microsoft Windows. It features large elements of realism and simulation; a blend of large-scale military conflict spread across large areas alongside the more close quartered battles.

## ARMA III
[arma 3](arma3/)

## ARMA III headless client
[arma 3 headless](arma3_headless_client/)