# Stock pterodactyl eggs

eggs based on the stock [pterodactyl eggs](https://github.com/pterodactyl/panel/tree/develop/database/seeds/eggs)

These are mostly fixes that should make it into the main repo eventually as I pr them over.