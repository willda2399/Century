# TS3 Manager
### [Website](https://www.ts3.app/)

TS3 Manager is a simple and lightwight webbased Teamspeak Webinterface

### Install notes

Connect with your IP from your Pteroserver and the assigned Port. Add your IP to TS Server Withlist

### Server Ports
Ports required to run the server in a table format.

| Port    | default |
|---------|---------|
| Game    | 3000    |
